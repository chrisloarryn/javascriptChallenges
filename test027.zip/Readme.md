El codigo solo require tener instalado node.js, ademas para comodidad de ejecucion recomiendo instalar

- nodemon (`npm i -g nodemon`)
- luego correr node test027.js || nodemon test027.js